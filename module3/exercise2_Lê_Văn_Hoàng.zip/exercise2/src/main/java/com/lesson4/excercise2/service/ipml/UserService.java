package com.lesson4.excercise2.service.ipml;

import com.lesson4.excercise2.entity.User;
import com.lesson4.excercise2.repository.UserRepository;
import com.lesson4.excercise2.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService implements IUserService {

    @Autowired
    private UserRepository repository;

    @Override
    public List<User> getUsers() {
        return repository.findAll();
    }

    @Override
    public User getUserById(int id) {
        return repository.findById(id).orElse(null);
    }

    @Override
    public User getUserByName(String name) {
        return repository.findByName(name);
    }

    @Override
    public String deleteUser(int id) {
         repository.deleteById(id);
         return "Remove Success" + id;
    }

    @Override
    public User saveUser(User user) {
        return repository.save(user);
    }

    @Override
    public User UpdateUser(User user) {
        User oldUser = repository.findById(user.getId()).orElse(null);
        oldUser.setName(user.getName());
        oldUser.setDateOfBirth(user.getDateOfBirth());
        oldUser.setAddress(user.getAddress());
        return repository.save(oldUser);
    }
}
