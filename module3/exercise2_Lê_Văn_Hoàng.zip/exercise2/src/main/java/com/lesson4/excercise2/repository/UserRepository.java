package com.lesson4.excercise2.repository;

import com.lesson4.excercise2.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserRepository extends JpaRepository<User,Integer> {
    User findByName(String name);
}
