package com.lesson4.excercise2.service;

import com.lesson4.excercise2.entity.User;

import java.util.List;

public interface IUserService {
    public List<User> getUsers();
    public User getUserById(int id);
    public User getUserByName(String name);
    public String deleteUser(int id);
    public User saveUser(User user);
    public User UpdateUser(User user);

}
